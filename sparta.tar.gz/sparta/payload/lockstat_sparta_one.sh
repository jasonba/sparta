#!/usr/bin/bash
#
# Program       : lockstat_sparta_one.sh
# Author        : Jason.Banham@Nexenta.COM
# Date          : 2020-06-05
# Version       : 0.01
# Usage         : lockstat_one.sh
# Purpose       : Gather lockstat statistics for a NexentaStor appliance, part of the SPARTA suite
# Legal         : Copyright 2020, Nexenta Systems, Inc. 
#
# History       : 0.01 - Initial version
#

#
# Configuration file locations
#
SPARTA_CONFIG=/perflogs/etc/sparta.config

#
# Tunables
#
MAX_SIZE=10485760		# 10MB max file size

#
# Pull out configurations details from the resource monitor config file
#
if [ -s $SPARTA_CONFIG ]; then
    source $SPARTA_CONFIG
else
    echo "The performance monitor configuration file is missing or empty, must exit."
    exit 1
fi

#
# Performance samples are collated by day (where possible) so figure out the day
# This should really be handled by the main SPARTA script, so probably redundant
# but may be useful if run outside of SPARTA
#
if [ ! -d $LOG_DIR/samples ]; then
    $MKDIR -p $LOG_DIR/samples
    if [ $? -ne 0 ]; then
        $ECHO "Unable to create $LOG_DIR/samples directory to capture statistics"
        exit 1
    fi
fi

#
# Gather one sample
#
PERIOD="$($DATE '+%Y-%m-%d_%H:%M:%S')"
$ECHO $PERIOD >> $LOG_DIR/samples/watch_cpu/lockstat-Ccwp.out.$PERIOD
$LOCKSTAT $LOCKSTAT_CONTENTION_OPTS >> $LOG_DIR/samples/watch_cpu/lockstat-Ccwp.out.$PERIOD 2>&1 
$ECHO $PERIOD >> $LOG_DIR/samples/watch_cpu/lockstat-kIW.out.$PERIOD
$LOCKSTAT $LOCKSTAT_PROFILING_OPTS >> $LOG_DIR/samples/watch_cpu/lockstat-kIW.out.$PERIOD 2>&1 
